# Обзор для внедрения / отрасли

Для руководителя внедрения и тех, кто поднимает контур у организации.

## В одном абзаце

EliteEW — **рабочая среда** и **дар миру** по AGPL: организация принимает
код, разворачивает свой экземпляр силами ИТ/SI и живёт в своём контуре.
Сопровождение (если нужно) — опция, не замена дара сопровождением. Структура затрат
self-host — ориентир по ФОТ/хосту, не тариф на код
([P3d](03d-tco-orientative.md) · [P3e](03e-delivery-models.md)).

## Карта

| Тема | Глава |
|------|-------|
| Что это | [P1](01-what-is-eliteew.md) |
| Дар / AGPL / copyleft | [P3c](03c-full-complex-source.md) |
| Как пользоваться даром | [P3e](03e-delivery-models.md) |
| День сотрудника | [P3a](03a-employee-day-adoption.md) |
| Отраслевые акценты | [P3b](03b-industry-profiles.md) |
| Принять у себя | [P3f](03f-transfer-bom-handover.md) |
| Миграция с зоопарка | [P3g](03g-si-migration-playbook.md) |
| Роли | [P5a](05a-roles-org-project.md) |
| Файлы | [P4a](04a-files-two-planes.md) |
| Границы | [P12](12-honest-limits.md) |
