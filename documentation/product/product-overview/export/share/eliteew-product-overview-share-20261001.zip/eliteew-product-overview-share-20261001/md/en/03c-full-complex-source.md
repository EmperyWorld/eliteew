# P3c — The complex, open source, gift to the world

## Core idea

EliteEW is given to the world as **free software**. First-party code defaults to
`AGPL-3.0-or-later` (repository root `LICENSE`). That is about **freedom to use
and share**, not about a tariff for “opening the repo.”

1. **A full complex** — not “one chat” and not “one drive”: desk, apps, files,
   communications, AI, mobile companion, editions (cloud / on-prem / client) in
   one platform.
2. **Your instance** — a deployed organizational contour stays **yours**
   (especially on-prem), not a shared demo account.
3. **Free source** — you may run, study, modify, and redistribute first-party
   code under AGPL. Public source / network-notice reference:
   [github.com/EmperyWorld/eliteew](https://github.com/EmperyWorld/eliteew)
   (see also the platform license map).
4. **Network copyleft** — if you make a **modified** network service available to users,
   those users must receive the *corresponding source* of that version. That
   does **not** mean publishing production secrets, personal data, private keys,
   or trademark rights.
5. **Not one license for the whole tree** — first-party default is
   AGPL-3.0-or-later; explicit exceptions (e.g. MIT) and third-party components
   keep their own SPDX / NOTICE / SBOM. Map:
   `documentation/platform/THIRD-PARTY-LICENSE-MAP.md`.

## What AGPL does not move

The EliteEW name and logo are not “part of AGPL.” Forks and modifications follow
the code license; presenting a fork as official EliteEW without a separate mark
agreement is out of scope.

How to live with the gift in practice — [P3e](03e-delivery-models.md).  
How to accept release artifacts in-house — [P3f](03f-transfer-bom-handover.md).
