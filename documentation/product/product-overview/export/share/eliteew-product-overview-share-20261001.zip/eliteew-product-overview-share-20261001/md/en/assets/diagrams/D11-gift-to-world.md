# D11 — Gift to the world: AGPL and optional accompaniment (P3e)

```mermaid
flowchart LR
  Gift["Gift to the world · AGPL first-party"]
  Gift --> Run["Run / study / modify"]
  Gift --> Share["Share under AGPL"]
  Gift --> Net["Modified network service → source to its users"]
  Run --> Org["Organization’s own contour"]
  Share --> Org
  Help["Optional accompaniment"]
  Help --> Accept["Help with acceptance / SBOM"]
  Help --> Ops["Help with operations"]
  Accept --> Org
  Ops --> Org```

принять и крутить контур, но **не** подменяет и не закрывает исходники.
